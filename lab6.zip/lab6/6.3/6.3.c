#include <at89c5131.h>

sbit LED=P0^7;

//Functions prototype
void timerdelay(int h, int l);

/*
The 8051 has two timers T0 and T1.
When used as timers, the 8051 timers count up every 12th clock cycle.
That means for oscillator clock of 24MHz the timer count increments at the rate 24MHz/12 i.e. 2MHz
So one upcount in timer registers takes 0.5 microseconds.

So to get 4ms delay we need to count for 4ms/0.5us = 8000 count

Hexadecimal value of -8000 is E0C0H

OR 

8000 in hex will be 1F40 . So, 10000 - 1F40 = E0C0H

*/

//Main function
void main(void)
{
	TMOD = 0x11; //Timer 1 in mod 1
  while(1)
	{ int i;
		for(i=100;i>0;i--){
		TH0=0xD8;
		TL0=0xF0;
		TR0=1;
		while(TF0==0){
		LED = 1;
		timerdelay(0xEF, 0xB9);
		LED = 0;
		timerdelay(0xEF, 0xB9);
	}
		TR0=0;
	TF0=0;

}
				for(i=150;i>0;i--){
		TH0=0xD8;
		TL0=0xF0;
		TR0=1;
		while(TF0==0){
		LED = 1;
		timerdelay(0xF1, 0x88);
		LED = 0;
		timerdelay(0xF1, 0x88);
	}
		TR0=0;
	TF0=0;

}
						for(i=200;i>0;i--){
		TH0=0xD8;
		TL0=0xF0;
		TR0=1;
		while(TF0==0){
		LED = 1;
		timerdelay(0xF2, 0xFB);
		LED = 0;
		timerdelay(0xF2, 0xFB);
	}
		TR0=0;
	TF0=0;

}
			for(i=100;i>0;i--){
		TH0=0xD8;
		TL0=0xF0;
		TR0=1;
		while(TF0==0){
		LED = 1;
		timerdelay(0xF3, 0xCB);
		LED = 0;
		timerdelay(0xF3, 0xCB);
	}
		TR0=0;
	TF0=0;

}	
			for(i=200;i>0;i--){
		TH0=0xD8;
		TL0=0xF0;
		TR0=1;
		while(TF0==0){
		LED = 1;
		timerdelay(0xF5, 0x26);
		LED = 0;
		timerdelay(0xF5, 0x26);
	}
		TR0=0;
	TF0=0;

}
			for(i=150;i>0;i--){
		TH0=0xD8;
		TL0=0xF0;
		TR0=1;
		while(TF0==0){
		LED = 1;
		timerdelay(0xF6, 0x36);
		LED = 0;
		timerdelay(0xF6, 0x36);
	}
		TR0=0;
	TF0=0;

}
			for(i=200;i>0;i--){
		TH0=0xD8;
		TL0=0xF0;
		TR0=1;
		while(TF0==0){
		LED = 1;
		timerdelay(0xF7, 0x52);
		LED = 0;
		timerdelay(0xF7, 0x52);
	}
		TR0=0;
	TF0=0;

}
			for(i=100;i>0;i--){
		TH0=0xD8;
		TL0=0xF0;
		TR0=1;
		while(TF0==0){
		LED = 1;
		timerdelay(0xF7, 0xDD);
		LED = 0;
		timerdelay(0xF7, 0xDD);
	}
		TR0=0;
	TF0=0;

}}
	}


void timerdelay( int h, int l)
{
	TL1 = l; //Starting Count value
	TH1 = h;
	TR1 = 1; //Start bit indicates the counting starts
	while(TF1 == 0); //Checks overflow that is FFFFH to 0000H
	TR1 = 0; //Stops the timer
	TF1 = 0;
}
