#include <at89c5131.h>
#include "lcd.h"    // Header file with LCD interfacing functions
#include "serial.h" // Header file with UART interfacing functions

sbit LED4 = P1 ^ 7;
sbit LED3 = P1 ^ 6;
sbit LED2 = P1 ^ 5;
sbit LED1 = P1 ^ 4;

	
enum state
{
  INITIAL,
  STATE_A,
  STATE_W
};

// Main function
void main(void)
{
  unsigned char ch = 0;
  enum state state_t = INITIAL;
  int bal_1 = 10000;
  int bal_2 = 10000;
  unsigned char account_n = 0;
  unsigned char bal = 0;
  unsigned int withdraw = 0;
  unsigned int temp = 0;
  unsigned int hundred = 0;
  unsigned int five_hundred = 0;
  unsigned char temp_char[5] = 0;
  uart_init();
  while (1)
  {
    // Receive a character

    if (state_t == INITIAL)
    {

      transmit_string("Press A for Account display and W for withdrawing cash\r\n");
      ch = receive_char();
      if (ch == 'A')
      {
        state_t = STATE_A;
        msdelay(100);
      }
      else if (ch == 'W')
      {

        state_t = STATE_W;
        msdelay(100);
      }
    }

    else if (state_t == STATE_A)
    {

      transmit_string("Hello, Please enter Account Number.\r\n");
      ch = receive_char();
      if (ch == '1')
      {
        transmit_string("Account Holder: Steven\r\n");
        transmit_string("Account Balance: \r\n");
        int_to_string(bal_1, temp_char);
        transmit_string(temp_char);
        msdelay(100);
        state_t = INITIAL;
      }
      else if (ch == '2')
      {
        transmit_string("Account Holder: Gordon\r\n");
        transmit_string("Account Balance: ");
        int_to_string(bal_2, temp_char);
        transmit_string(temp_char);
				transmit_string("\r\n");
        msdelay(100);
        state_t = INITIAL;
      }
      else
      {
        transmit_string("No such account, please enter valid details.\r\n");
        msdelay(100);
        state_t = INITIAL;
      }
    }

    else if (state_t == STATE_W)
    {
      ch = receive_char();
      transmit_string("Withdraw state, enter account number.\r\n");
      if (ch == '1')
      {
        transmit_string("Account Holder: Steven\r\n");
        transmit_string("Account Balance: ");

        int_to_string(bal_1, temp_char);
        transmit_string(temp_char);
        transmit_string("\r\n");
        transmit_string("Enter Amount, in hundreds: ");
        bal = receive_char();
        ch = receive_char();
        withdraw = (int)bal;
        temp = (int)ch;

        if ((withdraw <= 57 && withdraw >= 48) && (ch <= 57 && withdraw >= 48))
        {

          withdraw -= 48 ; 
          withdraw *= 1000;
          withdraw += 100 * (temp-48);

          if (withdraw <= bal_1)
          {
            // calculating the amount that needs to be given
            five_hundred = withdraw / 500;
            hundred = (withdraw - five_hundred * 500)/100;
            bal_1 = bal_1 - withdraw;

            transmit_string("\r\n");
						transmit_string("Remaining balance: ");
            int_to_string(bal_1, temp_char);
            transmit_string(temp_char);
						transmit_string("\r\n");
            transmit_string("500 notes: ");
            int_to_string(five_hundred, temp_char);
						transmit_string(temp_char);
						transmit_string("\r\n");
            transmit_string("100 notes: ");
            int_to_string(hundred, temp_char);
            transmit_string(temp_char);

            msdelay(100);
            state_t = INITIAL;
          }
          else
          {
            transmit_string("Insufficient Funds");
            msdelay(100);
            state_t = INITIAL;
          }
        }
        else
        {
          transmit_string("Invalid Amount");
          msdelay(100);
          state_t = INITIAL;
        }
      }
      else if (ch == '2')
      {
        transmit_string("Account Holder: Gordon\r\n");
        transmit_string("Account Balance: ");
        int_to_string(bal_2, temp_char);
        transmit_string(temp_char);
				transmit_string("\r\n");
        transmit_string("Enter Amount, in hundreds: ");
        bal = receive_char();
        ch = receive_char();
        withdraw = (int)bal;
        temp = (int)ch;

        if ((withdraw <= 57 && withdraw >= 48) && (ch <= 57 && withdraw >= 48))
        {
					withdraw -= 48 ; 
          withdraw *= 1000;
          withdraw += 100 * (temp-48);
					

          if (withdraw <= bal_2)
          {
            // calculating the amount that needs to be given
            five_hundred = withdraw / 500;
            hundred = (withdraw - five_hundred * 500)/100;
            bal_2 = bal_2 - withdraw;

            transmit_string("Remaining balance: ");
            int_to_string(bal_2, temp_char);
            transmit_string(temp_char);
						transmit_string("\r\n");
            transmit_string("500 notes: ");
            int_to_string(five_hundred, temp_char);
						transmit_string(temp_char);
						transmit_string(" \r\n");
            transmit_string("100 notes: ");
            int_to_string(hundred, temp_char);
            transmit_string(temp_char);
            msdelay(100);
            state_t = INITIAL;
          }
          else
          {
            transmit_string("Insufficient Funds");
            msdelay(100);
            state_t = INITIAL;
          }
        }
        else
        {
          transmit_string("Invalid Amount");
          msdelay(100);
          state_t = INITIAL;
        }
      }

      msdelay(100);
    }
  }
}
