#include <at89c5131.h>
#include "lcd.h"
#include "math.h"
#include "stdio.h"

void main()
{ int x1, x2, y1;
	signed int w0= -36;
	signed int w1=5;
	signed int w2=7;
	lcd_init();
	lcd_cmd(0x80);													//Move cursor to first line
	msdelay(4);
	lcd_write_string("Input 1:");
	//lcd_cmd(0xC0);		//Move cursor to 2nd line of LCD
	P1= 0x0F;
	msdelay(5000);
	x1=P1;
	lcd_cmd(0x80);													//Move cursor to first line
	msdelay(4);    
	lcd_write_string("Input 2:");
	P1= 0x0F;
	msdelay(5000);
	x2=P1;
	msdelay(5000);
	y1=w0+(x1*w1)+(x2*w2);
	
	if(y1<0)
	{
		lcd_cmd(0x80);													//Move cursor to first line
	msdelay(4);
	lcd_write_string("Prediction:");
	lcd_cmd(0xC0);
  msdelay(4);
  lcd_write_string("Class 1");
	}
  else
	{
			lcd_cmd(0x80);													//Move cursor to first line
	msdelay(4);
	lcd_write_string("Prediction:");
	lcd_cmd(0xC0);
  msdelay(4);
  lcd_write_string("Class 2");
	}
	while(1);
		
}