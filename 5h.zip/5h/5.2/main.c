#include <at89c5131.h>
#include "lcd.h"
#include "math.h"
#include "stdio.h"

void main()
{ int x1, x2, y1,y;
	float z, v1, v2;
	signed int w0= -36;
	signed int w1=5;
	signed int w2=7;
	lcd_init();
	lcd_cmd(0x80);													//Move cursor to first line
	msdelay(4);
	lcd_write_string("Input 1:");
	//lcd_cmd(0xC0);		//Move cursor to 2nd line of LCD
	P1= 0x0F;
	msdelay(5000);
	x1=P1;
	lcd_cmd(0x80);													//Move cursor to first line
	msdelay(4);    
	lcd_write_string("Input 2:");
	P1= 0x0F;
	msdelay(5000);
	x2=P1;
	msdelay(5000);
	y1=w0+(x1*w1)+(x2*w2);
	y=-y1;
	
	z=(float)(1/(1+pow(2.718,y)));
	v1=1-z;
	v2=z;
	lcd_cmd(0x80);													//Move cursor to first line
	msdelay(4);    
	lcd_write_string("P(Class 1)=");
	lcd_float(v1);
	lcd_cmd(0xC0);													//Move cursor to first line
	msdelay(4);    
	lcd_write_string("P(Class 2)=");
	lcd_float(v2);
	while(1);
}